# ReadLens - Product Rules

These rules keep the project focused.

## Rule 1

The reader is the product.

AI is a layer on top, not the main screen.

## Rule 2

Do not show a permanent chatbot panel in the default reader.

## Rule 3

Most AI information should appear only after text selection.

## Rule 4

Keep first responses short.

The user can ask for more.

## Rule 5

Do not destroy the user's reading position when opening AI help.

## Rule 6

Deselecting text should normally dismiss the temporary AI state.

## Rule 7

Annotations belong to documents and must persist.

## Rule 8

Never rewrite the original document for normal annotation.

## Rule 9

The application should work even if AI is down.

Reading must not depend on AI availability.

## Rule 10

Mobile support is part of the first release.

Do not treat mobile as a later cleanup.

## Rule 11

Avoid building complex infrastructure before proving the core interaction.

## Rule 12

Prioritize this loop above everything else:

Read -> Select -> Understand -> Save -> Continue.

## Rule 13

Do not automatically generate expensive AI content for the entire book.

Use on-demand AI.

## Rule 14

Make privacy understandable.

The user should know what is stored and what is sent to AI.

## Rule 15

Every feature should answer a clear question:

"Does this help the user read, understand, remember, or find information?"

If not, leave it out of V1.
