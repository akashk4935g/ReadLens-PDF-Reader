# ReadLens - AI Behaviour Specification

## 1. Core rule

AI should answer the user's actual request and stay concise by default.

The user is reading a document, not chatting with an AI.

## 2. Meaning response

For a word or phrase:

Return:

1. Short meaning
2. Synonyms if useful
3. One example

Keep it short.

## 3. Context response

The AI should explain what the selection means in the current document.

It should use:

- Selection
- Sentence
- Nearby content
- Chapter context when available

If context is not enough, say so instead of inventing an answer.

## 4. Simplify response

The system should preserve meaning while making the language easier.

Modes:

- Normal
- Simple
- Like I am 10
- One sentence

## 5. Summarisation

For selected text:

- Identify the main point
- Remove repetition
- Keep important facts
- Avoid adding new claims

For a chapter:

- Main idea
- Key concepts
- Important arguments
- Important terms

## 6. Translation

Translate only the selected content unless the user specifically asks for more.

Do not unnecessarily add explanations.

## 7. Related concepts

Return a small number of strongly related concepts.

Avoid generating a giant list.

## 8. Hallucination control

The AI should distinguish between:

- What is present in the document
- What is inferred
- What is general knowledge

For document-grounded answers, prefer the document.

When uncertain, state uncertainty.

## 9. Context size

Do not send an entire large book with every request.

Suggested order:

```text
Selection
+
Current sentence
+
Nearby paragraph
+
Relevant chunks
+
Relevant user notes
```

## 10. AI caching

Identical requests can be cached.

Use an input hash based on:

- document version
- selected text
- action
- relevant context

Do not cache private data globally across users.

## 11. AI failure behaviour

If AI is unavailable:

The document reader should continue to work.

Show:

"AI help is temporarily unavailable."

Do not block reading.

## 12. AI UI language

Use clear wording:

- Understanding selection...
- Summarising...
- Translating...
- No useful context found.
- Try selecting a little more text.

Avoid technical messages such as API errors.

## 13. Cost control

AI should be invoked only when necessary.

Avoid automatic AI calls for every page.

On-demand actions are better for V1.
