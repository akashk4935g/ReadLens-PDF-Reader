# ReadLens - Project Overview

## 1. What is ReadLens?

ReadLens is a web-first document reader with built-in AI help.

The main idea is simple:

> Read normally. Select something when you need help. Get useful information without leaving the document.

The first version should support PDF files well. DOCX support can be added after the PDF experience is stable.

ReadLens should not feel like a chatbot with a document attached. It should feel like a clean document reader that becomes intelligent when the user asks for help.

## 2. Main user flow

1. User opens ReadLens.
2. User uploads a PDF.
3. The document opens in a clean reader.
4. The user reads normally.
5. User selects a word, phrase, sentence, or paragraph.
6. A small contextual menu appears.
7. A bottom panel shows useful information.
8. User can close the panel simply by deselecting text.
9. User can highlight text, add a comment, copy text, or ask AI to summarise/explain it.
10. User can open the Notes section later and see all saved highlights and comments.
11. The document is stored in Recent files.
12. When reopened, the app restores reading position and all saved changes.

## 3. Product principles

### Keep reading first

The book/document is always the main content. AI should not take over the screen unless the user asks for it.

### Minimal interface

Avoid unnecessary buttons, sidebars, popups, and permanent AI controls.

### Context matters

The same word can have different meanings in different documents. AI should consider the selected text and nearby document context.

### Changes must persist

Highlights, comments, notes, and reading position should survive closing and reopening the document.

### Mobile matters from day one

The layout should be responsive and comfortable on phones, tablets, and desktop browsers.

## 4. First release goal

The first deployable web version should achieve this complete loop:

Upload PDF -> Read -> Select text -> See meaning -> Highlight/comment -> Save -> Close -> Reopen -> Continue reading.

Anything outside this loop is secondary for the first release.

## 5. Target users

- Students reading textbooks
- People reading books
- Researchers reading papers
- Professionals reading reports
- Anyone who reads documents and often needs quick explanations

## 6. Suggested product name

Working name: **ReadLens**

Possible tagline:

**Read. Understand. Continue.**

The name can change later. Do not let naming delay development.

## 7. Web-first strategy

The first version should run entirely as a web application.

Recommended approach:

- Responsive web interface
- Desktop browser support
- Mobile browser support
- Installable as a PWA later
- Cloud storage only when needed
- Separate AI service layer so the AI provider can be changed later

Do not build native Android/iOS apps for the first version.
