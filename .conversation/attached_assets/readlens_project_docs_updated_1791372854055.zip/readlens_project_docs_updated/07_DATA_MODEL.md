# ReadLens - Data Model

## 1. User

```text
User
- id
- email
- displayName
- createdAt
```

## 2. Document

```text
Document
- id
- userId
- title
- fileName
- fileType
- storageKey
- pageCount
- status
- progress
- currentPage
- createdAt
- updatedAt
- lastOpenedAt
```

Status examples:

- uploading
- processing
- ready
- failed

## 3. Annotation

```text
Annotation
- id
- documentId
- userId
- pageNumber
- selectedText
- startOffset
- endOffset
- type
- comment
- createdAt
- updatedAt
```

## 4. Highlight

A highlight can use the same annotation structure or a linked model.

Fields:

```text
highlightId
annotationId
highlightType
```

Types:

- important
- definition
- question
- confusing
- idea
- normal

## 5. AI result

```text
AIResult
- id
- userId
- documentId
- annotationId
- action
- inputHash
- response
- createdAt
```

Possible actions:

- meaning
- simplify
- summarise
- translate
- context
- relatedConcepts

## 6. Note

```text
Note
- id
- userId
- documentId
- annotationId
- noteText
- aiNote
- createdAt
- updatedAt
```

## 7. Search record

Future model:

```text
DocumentChunk
- id
- documentId
- pageNumber
- text
- embedding
- metadata
```

## 8. Reading session

Optional future model:

```text
ReadingSession
- id
- userId
- documentId
- startedAt
- endedAt
- startingPage
- endingPage
```

This can help with reading statistics later.

## 9. Storage rule

The original document should be treated as immutable.

All user changes should live in the database.

This makes the system easier to recover, sync, and upgrade.
