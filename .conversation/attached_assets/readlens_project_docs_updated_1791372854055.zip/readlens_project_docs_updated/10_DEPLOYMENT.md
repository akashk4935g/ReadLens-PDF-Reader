# ReadLens - Web Deployment Guide

## 1. First deployment goal

Deploy a public web application that anyone with the link can open.

The architecture should be simple and easy to replace later.

## 2. Recommended services

A practical first setup:

- GitHub: source code
- Vercel or similar: web hosting
- PostgreSQL provider: database
- S3-compatible storage: uploaded documents
- AI provider: AI features

The exact providers can change.

## 3. Environment variables

Never commit secrets.

Example:

```text
DATABASE_URL=
STORAGE_ENDPOINT=
STORAGE_BUCKET=
STORAGE_ACCESS_KEY=
STORAGE_SECRET_KEY=

AI_API_KEY=

NEXT_PUBLIC_APP_URL=
```

Only variables explicitly intended for the browser should use `NEXT_PUBLIC_`.

AI secrets must remain server-side.

## 4. Deployment flow

```text
Developer
   |
   v
GitHub
   |
   v
Vercel / Hosting
   |
   +---- Web App
   |
   +---- API
   |
   +---- Database
   |
   +---- Storage
   |
   +---- AI service
```

## 5. Production file storage

Do not store large PDFs directly inside the application database.

Store:

- Metadata in PostgreSQL
- File bytes in object storage

The database should reference the storage key.

## 6. Security

Required before public launch:

- Authentication
- File size limits
- Allowed file types
- Private document storage
- Authorization on every document request
- Server-side AI keys
- Rate limits on AI requests
- Delete document function
- Logging for important failures

## 7. Monitoring

Track at least:

- Upload failures
- PDF processing failures
- AI failures
- API response time
- Database errors
- Storage errors

Do not log the full private document or private notes unnecessarily.

## 8. Backups

Database backups should be enabled.

Uploaded files should use a storage system with recovery options where possible.

## 9. Domain

Start with the hosting provider domain.

After the product is stable, connect a custom domain.

## 10. Mobile deployment

The first mobile experience is the responsive website.

After the responsive version is good:

- Add PWA manifest
- Add service worker
- Add install prompt
- Cache app shell
- Cache safe recent content

Do not create a native app before the web experience is proven.

## 11. Release checklist

Before public release:

- Test upload
- Test large PDF
- Test multi-page document
- Test text selection
- Test mobile selection
- Test highlight persistence
- Test comments
- Test notes
- Test AI errors
- Test document deletion
- Test login/logout
- Test private document access
- Test slow network
- Test small phone screen
- Test tablet
- Test desktop
- Test dark/light mode if included

## 12. Demo mode

For early testing, it can be useful to have a demo document.

This lets people see the product without uploading their own file.

The demo document should not expose private information.

## 13. Public launch rule

Do not call a prototype "production ready" until:

- User data access is protected
- File uploads are protected
- AI secrets are server-side
- Basic backup and recovery exist
- Errors are handled cleanly
