# ReadLens - Development Plan

## Phase 0 - Project setup

Goal:

Create a deployable web shell.

Tasks:

- Create Next.js project
- Add TypeScript
- Add Tailwind
- Set up linting and formatting
- Create base layout
- Add responsive navigation
- Set up Git repository
- Create environment variable structure

Deliverable:

A deployed blank ReadLens application.

## Phase 1 - Document reader

Goal:

Open a PDF and read it.

Tasks:

- Upload PDF
- Store temporary file
- Render PDF
- Page navigation
- Zoom
- Search
- Mobile layout
- Desktop layout

Deliverable:

A usable PDF reader.

## Phase 2 - Text selection

Goal:

Make document interaction reliable.

Tasks:

- Detect selected text
- Track page
- Track selection coordinates
- Show contextual toolbar
- Copy action
- Deselect behaviour

Deliverable:

Select text -> action toolbar appears.

## Phase 3 - Annotation

Goal:

Save user changes.

Tasks:

- Highlight
- Highlight categories
- Comment
- Save annotations
- Delete annotations
- Restore annotations after reopening

Deliverable:

Users can permanently annotate documents.

## Phase 4 - AI meaning

Goal:

Add the first AI feature.

Tasks:

- AI service interface
- Context gathering
- Meaning endpoint
- Synonyms
- Example
- Bottom panel
- Loading states
- Error states

Deliverable:

Select word -> meaning panel appears.

## Phase 5 - AI tools

Add:

- Explain simpler
- Summarise
- Translate
- Context explanation
- Related concepts

Do not build everything at once. Add one action at a time.

## Phase 6 - Notes

Tasks:

- Notes page
- Filters
- Open-in-document
- Note editing
- AI note support

Deliverable:

Saved information can be found and reused.

## Phase 7 - Recent and saved documents

Tasks:

- Recent files
- Saved files
- Continue reading
- Current page persistence
- Document deletion

Deliverable:

Documents feel persistent and personal.

## Phase 8 - Search improvements

Start with exact text search.

Then add:

- Semantic indexing
- Hybrid search
- Cross-document search

## Phase 9 - Advanced intelligence

Later:

- Chapter intelligence
- Formula understanding
- Cross-document intelligence
- Personal knowledge memory
- Reading modes
- PWA
- Offline support

## Definition of done for V1

V1 is successful when:

- A user can upload a PDF
- Open it on desktop and mobile
- Read without UI clutter
- Select text
- Get a short meaning
- Highlight it
- Add a comment
- Open Notes
- Close the document
- Reopen it
- See the annotation again
- Continue from the previous page
- Deploy the app publicly

Do not delay V1 for advanced AI features.
