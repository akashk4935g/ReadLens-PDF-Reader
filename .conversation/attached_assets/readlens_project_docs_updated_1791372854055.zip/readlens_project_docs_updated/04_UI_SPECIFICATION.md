# ReadLens - UI Specification

## 1. Main screens

First release screens:

1. Home
2. Upload
3. Reader
4. Notes
5. Search
6. Settings

## 2. Home screen

Desktop structure:

```text
-------------------------------------------------
ReadLens                         Search   Profile
-------------------------------------------------

Recent
-----------------------------------------------
Physics.pdf
44% complete

Atomic Habits.pdf
31% complete

Saved
-----------------------------------------------
Research Papers
Study Material
-----------------------------------------------
```

Mobile structure:

```text
--------------------------------
ReadLens                    ☰
--------------------------------

[ + Upload document ]

Recent
------------------------------
Physics.pdf
44% complete

Atomic Habits.pdf
31% complete
------------------------------

Bottom navigation:
Home | Notes | Search | Settings
```

## 3. Upload screen

Keep it simple.

```text
Upload document

[ Drop PDF here ]

or

[ Choose file ]

Supported: PDF
```

Show upload progress.

If the file cannot be processed, show a clear error.

Do not make the user configure AI settings during upload.

## 4. Reader screen

### Desktop

```text
┌──────────────────────────────────────────────────────┐
│ ←  Physics.pdf          184 / 420    🔍   ⋮        │
├──────────────────────────────────────────────────────┤
│                                                      │
│                  DOCUMENT PAGE                       │
│                                                      │
│              [actual PDF content]                    │
│                                                      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### Mobile

```text
┌───────────────────────────────┐
│ ← Physics.pdf       ⋮        │
├───────────────────────────────┤
│                               │
│       DOCUMENT PAGE           │
│                               │
│   [actual PDF content]        │
│                               │
│                               │
└───────────────────────────────┘
```

The reader should support vertical scrolling or page-based reading depending on the chosen PDF rendering library.

## 5. Text selection state

When text is selected:

```text
Selected text
     |
     v
┌──────────────────────────────┐
│ Copy Select Highlight ... AI │
└──────────────────────────────┘

Bottom panel appears
```

The page stays visible.

## 6. Meaning panel

Example:

```text
┌─────────────────────────────────┐
│ cognitive dissonance            │
│                                 │
│ Meaning                         │
│ Mental discomfort caused when   │
│ beliefs and actions conflict.   │
│                                 │
│ Synonyms                        │
│ mental conflict, inner conflict │
│                                 │
│ Example                         │
│ He felt uncomfortable because   │
│ his actions disagreed with his  │
│ beliefs.                        │
│                                 │
│ Explain simpler   Translate     │
└─────────────────────────────────┘
```

Keep the panel compact.

## 7. AI actions

Inside the AI area:

- Explain
- Summarise
- Explain simpler
- Translate
- Context
- Related concepts

Avoid presenting all options as large buttons.

Use a compact action row or tabs.

## 8. Notes screen

Desktop:

```text
Notes

[All] [Important] [Definitions] [Questions] [Ideas]

Physics.pdf
Page 42

"Electric field is..."
Highlight: Definition

Comment:
Need to revise this later.

[Open in document]
```

Mobile:

Use a vertical list with compact cards.

## 9. Search screen

Support both:

- Normal keyword search
- Future semantic search

Example:

```text
Search documents

[ where does the author discuss risk? ]

Results

Physics.pdf
Page 42
"...."

Research.pdf
Page 18
"...."
```

## 10. Settings

First release settings:

- Theme
- Language
- AI settings
- Privacy information
- Storage
- Delete document
- Clear local data

Keep the settings page simple.

## 11. Empty states

Every empty state needs a useful next step.

Example:

"No saved notes yet."

[Open a document]

Do not show empty screens with no action.

## 12. Error states

Errors should explain:

- What happened
- What the user can do
- Whether their document is safe

Example:

"Could not process this PDF."

"Try uploading another PDF or check that the file is not damaged."

## 13. Loading states

Use skeletons or small progress indicators.

For AI:

"Understanding selection..."

Avoid a full-screen loading overlay.
