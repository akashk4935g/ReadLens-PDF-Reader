# ReadLens - Feature Specification

## 1. Document upload

### Supported in first version

- PDF
- Maximum file size should be configurable by the backend
- File name and basic metadata should be stored

### Later

- DOCX
- EPUB
- TXT
- More document types

## 2. Clean document reader

The reader should provide only necessary controls.

Desktop:

- Back/home
- Document name
- Page number
- Previous/next page
- Zoom
- Search
- More options

Mobile:

- Back
- Document title
- Page indicator
- Search/menu
- Simple page controls

The document itself must get most of the screen.

## 3. Text selection

The user can select:

- A word
- A phrase
- A sentence
- A paragraph
- Multiple lines

On selection, show a contextual toolbar.

Toolbar actions:

- Copy
- Select all
- Highlight
- Add comment
- AI help

The selected text should remain visibly selected while the help panel is open.

## 4. Quick meaning

When the user selects a word or phrase, show a small bottom panel.

Suggested content:

### Meaning
A short explanation using simple language.

### Synonyms
2 to 4 useful alternatives when appropriate.

### Example
One short example sentence.

The panel should normally use less than half the screen.

## 5. Context-aware meaning

The AI should consider:

- Selected text
- The current sentence
- Nearby text
- Current page
- Chapter context when available

Example:

Selected word: "bank"

The system should explain the meaning used in that sentence instead of always giving a dictionary definition.

## 6. Explain simpler

The user can choose:

- Normal
- Simple
- Like I am 10
- One sentence

This should be a transformation of the selected content, not a long essay.

## 7. Translation

The selected text can be translated.

First version can support:

- English
- Hindi

The architecture should allow more languages later.

## 8. Related concepts

The system may show concepts related to the selected text.

Example:

Selected: "photosynthesis"

Related:

- Chlorophyll
- Glucose
- Cellular respiration
- Light-dependent reactions

Related concepts should be clickable later.

## 9. Smart highlights

Highlight types:

- Important
- Definition
- Question
- Confusing
- Idea

A normal highlight can also exist if the user does not want categories.

## 10. Comments

A comment belongs to a specific document location.

A comment should store:

- Selected text
- Page/position reference
- Comment text
- Created date
- Updated date

## 11. Notes section

The Notes section should show all saved items.

Each note card should include:

- Document name
- Selected text
- Page number
- Highlight type
- User comment
- Optional AI-generated note
- Date

Clicking a note should open the document and move to the original location.

## 12. Semantic document search

Search should eventually support natural questions.

Example:

"Where does this paper talk about risk?"

The system should return relevant passages, even when the exact word "risk" does not appear.

For the first release, normal text search is acceptable. Semantic search can be added after the basic reader works.

## 13. Where was this mentioned?

For a selected term, show other locations where the same concept or text is found.

Example:

"Opportunity cost"

- Page 18
- Page 32
- Page 74
- Page 101

Clicking an item opens the location.

## 14. Reading progress

Store:

- Current page
- Total pages
- Last opened time
- Approximate progress percentage

Example:

Physics.pdf
184 / 420
44%

## 15. Chapter intelligence

When enough document structure is available, generate:

- Main idea
- Important concepts
- Important passages
- Important terms
- Open questions

This can be an on-demand feature.

Do not generate expensive AI summaries for every page automatically.

## 16. Formula and equation help

For technical documents, selected equations can receive:

- Variable names
- Units when detectable
- Short meaning
- Basic interpretation

Advanced derivations can be a later feature.

## 17. Cross-document intelligence

Later, users can search across their saved documents.

Example:

"Show me where I have read about PID control."

Results may come from:

- Textbooks
- Research papers
- Notes
- Uploaded documents

This should be built on top of a separate knowledge index.

## 18. Personal knowledge memory

The user can save information for later.

Possible action:

"Remember this"

Saved concepts can later be grouped by topic.

This is a future major feature and should not block the first release.

## 19. Privacy mode

The product should clearly explain what happens to uploaded data.

Future goals:

- Local document processing where possible
- User-controlled AI processing
- Secure document storage
- Clear delete controls
- No hidden sharing

## 20. Reading modes

### Normal

Clean reading.

### Study

Makes notes, highlights, meanings, and related concepts easier to access.

### Research

Focuses on search, occurrences, references, and cross-document information.

### Revision

Focuses on highlights, notes, concepts, and chapter intelligence.
