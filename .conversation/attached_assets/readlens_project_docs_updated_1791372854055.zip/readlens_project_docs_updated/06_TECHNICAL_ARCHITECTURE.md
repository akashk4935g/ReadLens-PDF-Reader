# ReadLens - Technical Architecture

## 1. Recommended first stack

### Frontend

- React
- Next.js
- TypeScript
- Tailwind CSS

### PDF rendering

Use a mature browser PDF rendering library such as PDF.js or a higher-level React wrapper around it.

### Backend

For the first web release:

- Next.js API routes or a small Node.js service
- REST endpoints are enough for V1

### Database

Use PostgreSQL.

### File storage

Use object storage such as:

- S3-compatible storage
- Cloudflare R2
- Supabase Storage

The code should hide the provider behind a storage service interface.

### Authentication

For the first release, use a simple email/password or OAuth provider.

If authentication slows development, local/demo mode can be built first.

## 2. High-level architecture

```text
Browser
  |
  v
Next.js Web App
  |
  +--------------------+
  |                    |
  v                    v
API Layer          PDF Renderer
  |
  +----------+-----------+------------+
  |          |           |            |
  v          v           v            v
Database   File Store  AI Service   Search
```

## 3. Frontend modules

Suggested folder structure:

```text
src/
  app/
  components/
    reader/
    selection/
    ai-panel/
    notes/
    search/
    upload/
    layout/
  lib/
    api/
    pdf/
    ai/
    storage/
  hooks/
  types/
```

## 4. Reader component

Responsibilities:

- Load document
- Display pages
- Track current page
- Track text selection
- Provide zoom
- Open contextual toolbar
- Open bottom panel

It should not contain all AI business logic.

## 5. Selection state

A shared selection model should contain:

```text
documentId
pageNumber
selectedText
selectionCoordinates
startOffset
endOffset
```

Use stable references when possible.

This is important because annotations must remain attached to the correct text.

## 6. AI service

Create one internal AI interface:

```text
getMeaning(selection, context)
explainSimply(selection, context)
summarise(selection, context)
translate(selection, targetLanguage)
getRelatedConcepts(selection, context)
```

The frontend should not directly depend on a specific model provider.

## 7. Context service

When AI is called, gather only useful context.

Possible context layers:

1. Selected text
2. Sentence
3. Nearby paragraphs
4. Current page
5. Chapter
6. User notes
7. Relevant document chunks

Start small.

Do not send the entire book for every AI request.

## 8. Document processing pipeline

```text
Upload
  |
  v
Validate file
  |
  v
Store original
  |
  v
Extract text
  |
  v
Detect pages
  |
  v
Create searchable representation
  |
  v
Ready for reading
```

For scanned PDFs, OCR can be added later.

## 9. Search architecture

V1:

- Exact text search

V2:

- Text chunking
- Embeddings
- Vector search
- Hybrid search

Do not build a complicated vector system before the basic reader is working.

## 10. Annotation architecture

Store annotations separately from the original PDF.

Do not rewrite the PDF for every highlight.

Example:

```text
annotation
- id
- documentId
- userId
- pageNumber
- selectedText
- startOffset
- endOffset
- type
- color
- comment
- createdAt
- updatedAt
```

## 11. Reading progress

Store:

```text
documentId
userId
currentPage
scrollPosition
lastOpenedAt
progress
```

## 12. Cross-document index

Later, documents can be chunked into small searchable units.

Each chunk can contain:

```text
documentId
pageNumber
chunkText
embedding
metadata
```

Use vector search only after this structure is stable.

## 13. Security basics

Required:

- Authentication
- Authorization checks
- Private file paths
- Signed file URLs
- Server-side AI API keys
- Input validation
- File type validation
- Upload size limits
- Rate limiting

Never put an AI API key in frontend code.

## 14. API examples

Possible endpoints:

```text
POST /api/documents
GET  /api/documents
GET  /api/documents/:id

POST /api/annotations
PATCH /api/annotations/:id
DELETE /api/annotations/:id

POST /api/ai/meaning
POST /api/ai/summarise
POST /api/ai/explain
POST /api/ai/translate

GET /api/notes
GET /api/search
```

## 15. Deployment architecture

Simple web deployment:

```text
GitHub
  |
  v
Vercel / similar host
  |
  +---- Next.js
  |
  +---- API
  |
  +---- Database
  |
  +---- Object storage
  |
  +---- AI provider
```

This is enough for a first public prototype.

## 17. Final recommended stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16 + React 19 |
| Language | TypeScript |
| Styling | Tailwind CSS 4 |
| UI components | shadcn/ui |
| Icons | Lucide React |
| PDF rendering | PDF.js / `pdfjs-dist` |
| Backend | Next.js Route Handlers + Server Actions |
| Database | PostgreSQL through Supabase |
| Authentication | Supabase Auth |
| File storage | Supabase Storage |
| ORM | Drizzle ORM |
| AI integration | Vercel AI SDK |
| AI model provider | Provider-agnostic |
| Validation | Zod |
| Client state | React state + Zustand when needed |
| Search V1 | PostgreSQL full-text search |
| Search V2 | PostgreSQL + pgvector |
| Hosting | Vercel |
| Source control | GitHub |

### Why this stack

The first release should stay simple and use one main Next.js application.

Supabase gives the first version PostgreSQL, authentication, and file storage in one ecosystem.

PDF.js is important because ReadLens needs access to the PDF text layer for selection, highlighting, and contextual AI actions.

The Vercel AI SDK keeps the AI layer separate from the model provider, so the model can be changed later without rewriting the reader.

Do not add Kubernetes, microservices, Redis, or a separate vector database in V1 unless a real product requirement appears.

## 18. Initial package set

```bash
npm install pdfjs-dist @supabase/supabase-js @supabase/ssr drizzle-orm ai zod zustand lucide-react
```

Use the normal setup process for Next.js, Tailwind CSS, and shadcn/ui.

## 19. Architecture rule

Keep these concerns separate:

```text
Document
  -> original uploaded file

Reader
  -> displays document and handles selection

Annotations
  -> highlights, comments, and saved user changes

AI
  -> meaning, summaries, translation, context, related concepts
```

Do not place PDF rendering, database queries, and AI logic inside one large React component.

## 20. Why not a separate backend in V1?

Next.js can handle the web UI and server-side application work needed for the first release.

Use a separate backend only when scale, team structure, or a real technical requirement makes it useful.

## 21. Future upgrade path

```text
V1
Next.js + Supabase + PDF.js + AI SDK
       ↓
V2
+ document chunking
+ pgvector
+ semantic search
       ↓
V3
+ cross-document intelligence
+ personal knowledge memory
       ↓
V4
+ PWA/offline reading
+ private/local AI where practical
+ native mobile only if justified
```
