# ReadLens - Responsive and Mobile Specification

## 1. Goal

The same web application must work well on:

- Desktop
- Laptop
- Tablet
- Android phone
- iPhone-sized screens

This does not mean shrinking the desktop UI.

The layout should adapt.

## 2. Desktop layout

Desktop can use:

- Full reader area
- Top document toolbar
- Floating selection toolbar
- Bottom AI sheet
- Optional side navigation for notes/search when useful

Do not permanently reserve a large AI sidebar.

## 3. Tablet layout

Tablet should behave between desktop and mobile.

Use:

- Compact top toolbar
- Bottom AI sheet
- Comfortable text width
- Larger touch targets

## 4. Mobile layout

Mobile is a primary reading surface, not a reduced version.

Recommended:

- Top bar with back, title, menu
- Full-width document
- Bottom sheet for AI help
- Bottom navigation outside the reader
- Touch-friendly controls

## 5. Mobile selection

Text selection must not fight the browser's normal selection behavior.

The implementation should respect platform selection behavior and then add application actions in a safe way.

Do not depend on hover.

Every important action must have a tap alternative.

## 6. Bottom sheet behavior

Mobile AI sheet states:

### Closed

No panel.

### Compact

Around 25 to 40 percent of viewport height.

### Expanded

Can grow larger when the user asks for a long answer.

### Dismissed

Deselecting text or swiping down should dismiss it where technically safe.

## 7. Mobile notes

Notes should use a single-column list.

Each card should show:

- Document
- Page
- Selected text
- Highlight category
- Comment preview

The card can expand on tap.

## 8. Mobile navigation

Suggested bottom navigation:

Home | Notes | Search | Settings

The reader itself should remain focused.

When inside a document, the bottom navigation can be hidden or minimized.

## 9. Touch targets

Aim for comfortable finger-sized controls.

Avoid tiny icons placed close together.

## 10. Orientation

Support portrait.

Landscape should also work on tablets and larger phones.

The reader should use additional horizontal space without creating difficult-to-read text lines.

## 11. Performance

Mobile performance is critical.

Priorities:

- Lazy-load pages
- Avoid rendering all pages at once
- Cache frequently accessed pages
- Load AI only when requested
- Avoid large JavaScript bundles where possible

## 12. Offline basics

The first web version can support basic local caching.

Later, a full PWA can support:

- App installation
- Cached recent documents
- Offline reading
- Sync when online

AI features may still require a connection unless local AI is implemented.

## 13. Accessibility on mobile

Support:

- Zoom
- Text resizing where possible
- High contrast
- Screen readers
- Reduced motion
- Clear focus and active states
