# ReadLens - Final Technology Stack

## Recommended first stack

ReadLens should begin as a single web-first TypeScript project.

| Layer | Choice | Purpose |
|---|---|---|
| Framework | Next.js 16 + React 19 | Web app and server-side features |
| Language | TypeScript | Safer application code |
| Styling | Tailwind CSS 4 | Responsive UI |
| Components | shadcn/ui | Accessible, customizable components |
| Icons | Lucide React | Consistent icons |
| PDF | PDF.js (`pdfjs-dist`) | PDF rendering and text selection |
| Backend | Next.js Route Handlers + Server Actions | API and server logic |
| Database | PostgreSQL / Supabase | Users, documents, annotations, notes |
| Auth | Supabase Auth | Login and sessions |
| Storage | Supabase Storage | Private uploaded files |
| ORM | Drizzle ORM | Typed database access |
| AI | Vercel AI SDK | Model-independent AI integration |
| Validation | Zod | API and AI output validation |
| State | React state + Zustand when needed | UI state |
| Search V1 | PostgreSQL full-text search | Basic search |
| Search V2 | pgvector | Semantic and cross-document search |
| Hosting | Vercel | Web deployment |
| Source control | GitHub | Version control and CI/CD |

## Architecture

```text
                         READLENS
                            |
                    Next.js + React
                            |
        +-------------------+-------------------+
        |                   |                   |
        v                   v                   v
     PDF.js              App API            AI Service
        |                   |                   |
        |                   v                   v
        |              PostgreSQL          Vercel AI SDK
        |              / Supabase               |
        |                   |            Model Provider
        |                   |
        +----------+--------+
                   |
             Supabase Storage
```

## Why these choices?

### Next.js

Keeps the first web release in one project while providing both browser UI and server-side functionality.

### PDF.js

The central interaction is:

```text
Select text
   ->
Read selected text
   ->
Identify page/context
   ->
Show contextual toolbar
   ->
Open AI bottom sheet
```

PDF.js gives the application control over the PDF text layer instead of treating the document as a simple embedded viewer.

### Supabase

The first release needs:

- PostgreSQL
- Authentication
- File storage

Supabase provides these together and keeps the initial backend simple.

### Drizzle

Provides typed database access while staying close to SQL.

### Vercel AI SDK

Keep an internal AI service between the UI and the model provider:

```text
UI
 |
 v
ReadLens AI Service
 |
 v
Vercel AI SDK
 |
 +---- Provider A
 +---- Provider B
 +---- Provider C
```

This reduces provider lock-in.

## Search plan

### V1

PostgreSQL full-text search.

### V2

Create chunks and embeddings and store them with PostgreSQL + pgvector.

### V3

Hybrid search:

```text
Keyword search
      +
Semantic search
      |
      v
Relevant passages
      |
      v
AI response
```

Do not add a dedicated vector database in V1.

## Frontend structure

```text
src/
  app/
  components/
    reader/
    selection/
    ai/
    notes/
    search/
    upload/
    ui/
  lib/
    pdf/
    ai/
    db/
    storage/
    search/
  hooks/
  types/
```

## Initial dependencies

```bash
npm install pdfjs-dist @supabase/supabase-js @supabase/ssr drizzle-orm ai zod zustand lucide-react
```

Use the standard project setup for Next.js, Tailwind CSS, and shadcn/ui.

## What NOT to add in V1

Avoid unnecessary infrastructure:

- Kubernetes
- Microservices
- A dedicated vector database
- Redis unless needed
- A separate Python backend unless required
- Native Android/iOS apps initially

The goal is a reliable public web product first.

## Deployment

```text
GitHub
   |
   v
Vercel
   |
   +---- Next.js application
   |
   +---- Supabase PostgreSQL
   |
   +---- Supabase Storage
   |
   +---- AI provider
```

## Future growth

```text
V1 -> Web reader
V2 -> Semantic search
V3 -> Cross-document intelligence
V4 -> Personal knowledge memory
V5 -> PWA/offline support
V6 -> Native mobile only if justified
```

## Final recommendation

Start with:

**Next.js + React + TypeScript + Tailwind + shadcn/ui + PDF.js + Supabase + Drizzle + Vercel AI SDK + PostgreSQL.**

Keep the project as one clean web application until real requirements justify splitting it.
