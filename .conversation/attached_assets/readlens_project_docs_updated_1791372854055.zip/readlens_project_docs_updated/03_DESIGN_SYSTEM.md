# ReadLens - Design System

## 1. Design direction

The visual style should be:

- Clean
- Quiet
- Modern
- Comfortable for long reading sessions
- Professional
- Accessible
- Focused on content

The product should not look like a flashy AI dashboard.

## 2. Theme

Recommended default theme: light.

Reason:

Long documents are usually easier to read on a paper-like background.

Use a very light reading surface instead of a harsh pure white page when possible.

Recommended visual roles:

- Background: soft neutral
- Document page: white or near-white
- Primary text: very dark gray
- Secondary text: medium gray
- Border: light gray
- Accent: one clear brand color
- Success: green
- Warning: amber
- Error: red

Do not use many bright colors at the same time.

## 3. Dark mode

Dark mode should be supported after the base UI is stable.

Dark mode should use:

- Dark neutral background
- Slightly lighter document surface
- Light text
- Muted borders
- Same accent color with adjusted contrast

Avoid pure black backgrounds unless there is a strong accessibility reason.

## 4. Typography

Use a highly readable sans-serif UI font.

For document content, prefer the document's original font where possible.

UI hierarchy:

- Page title: large and strong
- Section title: medium-large
- Body text: normal
- Secondary text: smaller
- Labels: compact but readable

Do not use tiny text for important controls.

## 5. Spacing

Use a consistent spacing scale.

Suggested base: 4 px.

Examples:

- 4 px
- 8 px
- 12 px
- 16 px
- 24 px
- 32 px
- 48 px

Keep enough spacing around buttons so users can tap them comfortably.

## 6. Buttons

Use rounded rectangles with a moderate radius.

Primary actions should be visually stronger.

Secondary actions should be lighter.

Icon-only buttons need labels or accessible aria-labels.

## 7. Cards

Use cards only where they help group content.

Do not put every small piece of information in a card.

Notes, recent files, and search results can use cards or rows.

## 8. Bottom panel

The bottom AI panel is a key part of the product.

It should:

- Open from the bottom
- Have rounded top corners
- Have a clear drag or close affordance on mobile
- Occupy less than half the screen by default
- Expand only when the user asks for more

The document should remain visible whenever possible.

## 9. Context toolbar

When text is selected:

- Show near the selected area on desktop when possible
- Avoid covering the selected text
- On small screens, show a compact toolbar or bottom action row

Actions should be:

Copy | Select all | Highlight | Comment | AI

More actions can appear under a "More" control if needed.

## 10. Icons

Use one icon style across the application.

Good icon categories:

- Search
- Back
- Bookmark
- Highlight
- Comment
- Copy
- AI
- Notes
- Settings
- More

Never use icons without accessible labels when meaning is unclear.

## 11. Motion

Animation should be subtle.

Use motion for:

- Bottom panel opening
- Context toolbar appearing
- Page transitions
- Small state changes

Do not animate the document unnecessarily.

## 12. Accessibility

Minimum requirements:

- Keyboard navigation
- Visible focus states
- Good color contrast
- Screen-reader labels
- Touch-friendly target sizes
- Text resizing support
- No information conveyed by color alone

For selection and reading, do not rely only on color to show importance.
